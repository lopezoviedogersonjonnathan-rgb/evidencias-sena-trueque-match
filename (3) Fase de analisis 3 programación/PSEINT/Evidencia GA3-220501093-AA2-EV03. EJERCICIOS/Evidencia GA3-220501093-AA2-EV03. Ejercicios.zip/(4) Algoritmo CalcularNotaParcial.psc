//4. Un capital C est� situado a un tipo de inter�s R anual �al t�rmino de cu�ntos a�os se doblar�? 

//Si tienes un capital inicial C con un inter�s R% anual, cada a�o tu dinero crece.
//Ejemplo:	
//Capital inicial: $1,000,000
//Inter�s: 10% anual	
//A�o 1: $1,000,000 � 1.10 = $1,100,000
//A�o 2: $1,100,000 � 1.10 = $1,210,000
//A�o 3: $1,210,000 � 1.10 = $1,331,000
//...y as� hasta que llegue a $2,000,000 (el doble)
Algoritmo DoblarCapital
    Definir capital, capitalActual, interes Como Real
    Definir a�os Como Entero
    
    // Solicitar datos
    Escribir "Ingrese el capital inicial: "
    Leer capital
    Escribir "Ingrese la tasa de inter�s anual (en %): "
    Leer interes
    
    // Inicializar variables
    capitalActual <- capital
    a�os <- 0
    
    // Calcular cu�ntos a�os toma doblar el capital
    Mientras capitalActual < (capital * 2) Hacer
        capitalActual <- capitalActual * (1 + interes/100)
        a�os <- a�os + 1
    FinMientras
    
    // Mostrar resultado
    Escribir "El capital se doblar� en ", a�os, " a�os"
    Escribir "Capital inicial: $", capital
    Escribir "Capital final: $", capitalActual
    
FinAlgoritmo
